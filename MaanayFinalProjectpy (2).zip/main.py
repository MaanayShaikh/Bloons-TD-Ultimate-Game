"""
Bloons TD Ultimate FPT
"""
#Maanay Shaikh
#June 15th 2021
#ICS3U
#Remaking the TD Ultimate game using the language pygame.

import pygame
from pygame.locals import *
import sys
import math
import random

#Setup the screen
pygame.init()
pygame.mixer.init()
clock = pygame.time.Clock()
size = (800,600)
screen = pygame.display.set_mode(size)
pygame.display.set_caption("Bloons TD Ultimate!")


# Find centre of screen
screenWidth=800
screenHeight=600
centreX = screenWidth / 2
centreY = screenHeight / 2

#Setup initial values for some elements
bloontimer=200
bloontimer1=0
bloons=[[640,100]]
healthvalue=194
keys = [False, False, False, False]
playerpos = [100,260]

darts=[]

#Load images
player = pygame.image.load("Resources/Images/Dart_Monkey.png")
background = pygame.image.load("Resources/Images/grass_texture.jpg")
bridge = pygame.image.load("Resources/Images/bridge.png")
dart = pygame.image.load("Resources/Images/dart.png")
bloonimg1 = pygame.image.load("Resources/images/bloon.png")
bloonimg=bloonimg1
healthbar=pygame.image.load("Resources/images/healthbar.png")
health = pygame.image.load("Resources/images/health.png")

# 3.1 - Load audio
hit = pygame.mixer.Sound("resources/audio/balloon.mp3")
wmusic = pygame.mixer.Sound("resources/audio/win.mp3")
lmusic = pygame.mixer.Sound("resources/audio/lose.mp3")
leave = pygame.mixer.Sound("resources/audio/exit.wav")
hit.set_volume(0.25)
wmusic.set_volume(0.25)
lmusic.set_volume(0.3)
leave.set_volume(0.1)
pygame.mixer.music.load('resources/audio/background.mp3')
pygame.mixer.music.play(-1, 0.0)
pygame.mixer.music.set_volume(0.25)

#Set up fonts
tittleFont = pygame.font.SysFont("arial", 35, bold = True)
bigtittleFont = pygame.font.SysFont("arial", 40, bold = True)
instructionFont = pygame.font.SysFont("arial", 30, bold = True)
insFont = pygame.font.SysFont("arial", 20, italic = True, bold = True)
timeFont = pygame.font.Font(None, 24)

#Colours to use throughout
Black = (0,0,0)
White = (255,255,255)

#Initialize the game loop
running = True
intro = True
game = False
instruction = False
instruction2 = False
win = False
lose = False


# Main loop
while running:
  # check for any events
        for event in pygame.event.get():
    #check if 'x' was clicked
                if event.type == pygame.QUIT:
      # end the program
                        running = False
                        pygame.quit()
                        sys.exit()
#introduction loop
        while intro:
            screen.fill(0)
            #Draw the background image
            screen.blit(background,(0,0))
        #The bridges (this as well as the background image is used multiple times throughout the code)
            screen.blit(bridge, (0, 20))
            screen.blit(bridge, (0, 160))
            screen.blit(bridge, (0, 300))
            screen.blit(bridge, (0, 440))
            # check for some events
            for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                            pygame.quit()
                            sys.exit()
                    if event.type == pygame.KEYDOWN:
                #Play game
                            if event.key == pygame.K_p:
                                    intro = False
                                    game = True
                 #Quit window
                            elif event.key == pygame.K_q:
                                    pygame.quit()
                                    sys.exit()
                #Open Instructions
                            elif event.key == pygame.K_i:
                                    intro = False
                                    instruction = True

#Text block for ALL the information to start
            textTitle = bigtitleFont.render("BLOONS TD ULTIMATE!",False,White)
            textTitle2 = titleFont.render("press 'p' to play", False, Black)
            textTitle3 = titleFont.render("'i' for instructions", False, Black)
            textTitle4 = titleFont.render("and 'q' to quit", False, Black)
            textRect = textTitle.get_rect()
            textRect2 = textTitle2.get_rect()
            textRect3 = textTitle3.get_rect()
            textRect4 = textTitle4.get_rect()
            textRect.center = (centreX, 170)
            textRect2.center = (centreX, 250)
            textRect3.center = (centreX, 310)
            textRect4.center = (centreX, 370)
            screen.blit(textTitle,textRect)
            screen.blit(textTitle2,textRect2)
            screen.blit(textTitle3,textRect3)
            screen.blit(textTitle4,textRect4)

            pygame.display.update()

# Instruction loop containing information for user                 
            # check for key presses

        while instruction:
                screen.fill(0)
                #Background once again
                screen.blit(background,(0,0))
                screen.blit(bridge, (0, 20))
                screen.blit(bridge, (0, 160))
                screen.blit(bridge, (0, 300))
                screen.blit(bridge, (0, 440))
            
        # Text block for instructions of the game and how to go back or play game
                textInstructions = instructionFont.render("Congratulations! You have been Chosen", False, Black)
                textInstructions2 = instructionFont.render("To defeat the evil bloons and save monkeykind!", False, Black)
                textInstructions3 = insFont.render("Use the keys 's' and 'w' to move your monkey", False, Black)
                textInstructions4 = insFont.render("up or down in order to shoot the bloons.",False,Black)
                textInstructions5 = insFont.render("To shoot a dart, press the letter 'k'", False, Black)
                textInstructions6 = insFont.render("to shoot multiple, press 'k' repeatedly", False, Black)
                textInstructions7 = insFont.render("Press 'q' or the red x button at any time to end the game.",False, Black)
                textInstructions8 = insFont.render("Press 'n' for the next page, 'p' to start playing,", False, Black)
                textInstructions9 = insFont.render("'q' to quit, or 'm' to return to the menu", False, Black)
                insRect = textInstructions.get_rect()
                insRect2 = textInstructions2.get_rect()
                insRect3 = textInstructions3.get_rect()
                insRect4 = textInstructions4.get_rect()
                insRect5 = textInstructions5.get_rect()
                insRect6 = textInstructions6.get_rect()
                insRect7 = textInstructions7.get_rect()
                insRect8 = textInstructions8.get_rect()
                insRect9 = textInstructions9.get_rect()
                insRect.center = (centreX, 100)
                insRect2.center = (centreX,150)
                insRect3.center = (centreX, 200)
                insRect4.center = (centreX,250)
                insRect5.center = (centreX,300)
                insRect6.center = (centreX,350)
                insRect7.center = (centreX,400)
                insRect8.center = (centreX,450)
                insRect9.center = (centreX,500)
                screen.blit(textInstructions,insRect)
                screen.blit(textInstructions2,insRect2)
                screen.blit(textInstructions3,insRect3)
                screen.blit(textInstructions4,insRect4)
                screen.blit(textInstructions5,insRect5)
                screen.blit(textInstructions6,insRect6)
                screen.blit(textInstructions7,insRect7)
                screen.blit(textInstructions8,insRect8)
                screen.blit(textInstructions9,insRect9)

                pygame.display.update()
                
#Events corresponding to the keys clicked
                for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                                pygame.quit()
                                sys.exit()
                        if event.type == pygame.KEYDOWN:
                                #Begin the game
                                if event.key == pygame.K_p:
                                        instruction = False
                                        game = True
                                #Return to the menu
                                if event.key == pygame.K_m:
                                        instruction = False
                                        intro = True
                                #More Instructions
                                if event.key == pygame.K_n:
                                        instruction = False
                                        instruction2 = True
                                #Quit the game
                                elif event.key == pygame.K_q:
                                        pygame.quit()
                                        sys.exit()

# Next page of instructions                 
            # check for key presses

        while instruction2:
                screen.fill(0)
                screen.blit(background,(0,0))
                screen.blit(bridge, (0, 20))
                screen.blit(bridge, (0, 160))
                screen.blit(bridge, (0, 300))
                screen.blit(bridge, (0, 440))

# Text block for further instructions of the game and how to go back or play game
                textIns = insFont.render("Use 'a' and 'd' to move the monkey forward or back", False, Black)
                textIns2 = insFont.render("Hit the bloons with darts to pop them", False, Black)
                textIns3 = insFont.render("and prevent them reaching the bridges",False,Black)
                textIns4 = insFont.render("If a bloon reaches the bridge, you lose a life",False,Black)
                textIns5 = insFont.render("You have 50 lives, if you lose them all, you lose.", False, Black)
                textIns6 = insFont.render("To win, you must stay alive for 2 whole minutes", False, Black)
                textIns7 = insFont.render("Press p' to start playing, 'q' to quit,", False, Black)
                textIns8 = insFont.render("'b' to return to the first page, or 'm' to return to the menu", False, Black)
                textIns9 = insFont.render("Good luck! Have fun, and DO NOT LET THE BLOONS WIN!!", False, Black)
                insRect = textIns.get_rect()
                insRect2 = textIns2.get_rect()
                insRect3 = textIns3.get_rect()
                insRect4 = textIns4.get_rect()
                insRect5 = textIns5.get_rect()
                insRect6 = textIns6.get_rect()
                insRect7 = textIns7.get_rect()
                insRect8 = textIns8.get_rect()
                insRect9 = textIns9.get_rect()
                insRect.center = (centreX, 100)
                insRect2.center = (centreX,150)
                insRect3.center = (centreX,200)
                insRect4.center = (centreX,250)
                insRect5.center = (centreX,300)
                insRect6.center = (centreX,350)
                insRect7.center = (centreX,400)
                insRect8.center = (centreX,450)
                insRect9.center = (centreX,500)
                screen.blit(textIns,insRect)
                screen.blit(textIns2,insRect2)
                screen.blit(textIns3,insRect3)
                screen.blit(textIns4,insRect4)
                screen.blit(textIns5,insRect5)
                screen.blit(textIns6,insRect6)
                screen.blit(textIns7,insRect7)
                screen.blit(textIns8,insRect8)
                screen.blit(textIns9,insRect9)

                pygame.display.update()

#Events corresponding to the keys clicked
                for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                                pygame.quit()
                                sys.exit()
                        if event.type == pygame.KEYDOWN:
                                #Begin the game
                                if event.key == pygame.K_p:
                                        instruction2 = False
                                        game = True
                                #Return to the menu
                                if event.key == pygame.K_m:
                                        instruction2 = False
                                        intro = True
                                #More Instructions
                                if event.key == pygame.K_b:
                                        instruction2 = False
                                        instruction = True
                                #Quit the game
                                elif event.key == pygame.K_q:
                                        pygame.quit()
                                        sys.exit()

            #MAIN GAME LOOP

        #Game Loop
        while game:
                #check for any events
                for event in pygame.event.get():
                #quitting window tools
                        if event.type == pygame.QUIT:
                                pygame.quit()
                                sys.exit()
                        if event.type == pygame.KEYDOWN:
                                if event.key == pygame.K_q:
                                        pygame.quit()
                                        sys.exit()

                #enables the spawning of bloons
                bloontimer-=1

                #clear the screen before drawing it again
                screen.fill(0)
                #draw the background
                screen.blit(background,(0,0))
                screen.blit(bridge, (0, 20))
                screen.blit(bridge, (0, 160))
                screen.blit(bridge, (0, 300))
                screen.blit(bridge, (0, 440))
                #Set player position as well as rotating player with the mouse
                position = pygame.mouse.get_pos()
                angle = math.atan2(position[1]-(playerpos[1]+32),position[0]-(playerpos[0]+26))
                playerrot = pygame.transform.rotate(player, 360-angle*57.29)
                playerpos1 = (playerpos[0]-playerrot.get_rect().width/2, playerpos[1]-playerrot.get_rect().height/2)
                screen.blit(playerrot, playerpos1)
     #Enable the darts to pop bloons (bomb is just a variable)
                for bomb in darts:
                        index=0
                        velx=math.cos(bomb[0])*10
                        vely=math.sin(bomb[0])*10
                        bomb[1]+=velx
                        bomb[2]+=vely
                        #If a dart reaches the ends of the map,it will pop itself
                        if bomb[1]<-64 or bomb[1]>800 or bomb[2]<-64 or bomb[2]>600:
                            darts.pop(index)
                        index+=1
                        #Draw the darts
                        for projectile in darts:
                            dart1 = pygame.transform.rotate(dart, 360-projectile[0]*57.29)
                            screen.blit(dart1, (projectile[1], projectile[2]))

                # bloons will be drawn when bloontimer =0
                if bloontimer==0:
                        bloons.append([800, random.randint(30,570)])
                        bloontimer=200-(bloontimer1*2)
                        if bloontimer1>=35:
                            bloontimer1=35
                        else:
                            bloontimer1+=5
                index=0
                #If the bloon is offscreen, it will remove itself
                for bloon in bloons:
                        if bloon[0]<-64:
                            bloons.pop(index)
                #Speed of bloons
                        bloon[0]-=2
                        #when the bloons enter the bridge
                        bloonrect=pygame.Rect(bloonimg.get_rect())
                        bloonrect.top=bloon[1]
                        bloonrect.left=bloon[0]
                        if bloonrect.left<-5:
                        #Play sound for bloon whooshing by the defense
                            leave.play()
                            #lose lives (approx. 1 life as the total healthvalue is 194)
                            healthvalue -= 4
                            #pop the bloon
                            bloons.pop(index)
                      
                        # When the dart collides with the bloon
                        index1=0
                        for bomb in darts:
                            bomrect=pygame.Rect(dart.get_rect())
                            bomrect.left=bomb[1]
                            bomrect.top=bomb[2]
                            #Play popping sound and pop the bloon
                            if bloonrect.colliderect(bomrect):
                                hit.play()
                                bloons.pop(index)
                                darts.pop(index1)
                            index1+=1                
                #Draw the bloons
                        index+=1
                for bloon in bloons:
                        screen.blit(bloonimg, bloon)

                #Total ticks//60000 = the amount of minutes, and total ticks/1000 to %60 = the amount of seconds
                survivedtext = timeFont.render(str((pygame.time.get_ticks())//60000)+":"+str((pygame.time.get_ticks())//1000%60).zfill(2), True, (0,0,0))
                textRect = survivedtext.get_rect()
                textRect.topright=[795,5]
                screen.blit(survivedtext, textRect)

                #Draw the healthbar
                screen.blit(healthbar, (5,5))
                for health1 in range(healthvalue):
                        screen.blit(health, (health1+8,8))
                pygame.display.update()

                #Key presses to move the player up, down and sideways
                for event in pygame.event.get():
                        if event.type == pygame.KEYDOWN:
                                        #Go up
                                    if event.key==K_w:
                                        keys[0]=True
                                        keys[1]=False
                                        #Go to the left
                                    elif event.key==K_a:
                                        keys[1]=True
                                        keys[0]=False
                                        #Go down
                                    elif event.key==K_s:
                                        keys[2]=True
                                        keys[3]=False
                                        #Go to the right
                                    elif event.key==K_d:
                                        keys[3]=True
                                        keys[2]=False
                        if event.type == pygame.KEYUP:
                                    if event.key==pygame.K_w:
                                        keys[0]=False
                                        keys[1]=False
                                    elif event.key==pygame.K_a:
                                        keys[1]=False
                                        keys[0]=False
                                    elif event.key==pygame.K_s:
                                        keys[2]=False
                                        keys[3]=False
                                    elif event.key==pygame.K_d:
                                        keys[3]=False
                                        keys[2]=False

                        #When the mouse is clicked, the monket will shoot a dart
                        if event.type==pygame.MOUSEBUTTONDOWN:
                                position=pygame.mouse.get_pos()
                                darts.append([math.atan2(position[1]-(playerpos1[1]+32),position[0]-(playerpos1[0]+26)),playerpos1[0]+32,playerpos1[1]+32])

                #Using the keypresses to actually move the character
                if keys[0]:
                        playerpos[1]-=2
                elif keys[2]:
                        playerpos[1]+=2
                if keys[1]:
                        playerpos[0]-=1
                elif keys[3]:
                        playerpos[0]+=1

                pygame.display.update()

                #Win/Lose check
                #If you make it to 2 minutes, you win
                if pygame.time.get_ticks()>= 120000:
                        game=False
                        win=True
                        #Play win screen music
                        pygame.mixer.music.stop()
                        wmusic.play()
                #If you lose all of your lives, you lose
                if healthvalue <= 0:
                        game=False
                        lose=True
                        #Play lose screen music
                        pygame.mixer.music.stop()
                        lmusic.play()
                        
                
#Win end scenario
        while win:
                screen.fill(Black)

                #Text block for win screen
                winText = bigtitleFont.render("CONGRATS!",False, White)
                winText2 = insFont.render("Thanks to your triumphant victory", False, White)
                winText3 = insFont.render("over the bloons, the world remains", False, White)
                winText4 = insFont.render("at peace. At least... for now.", False, White)
                winText5=instructionFont.render("To quit: press 'q'", False, White)
                winRect = winText.get_rect()
                winRect2 = winText2.get_rect()
                winRect3 = winText3.get_rect()
                winRect4 = winText4.get_rect()
                winRect5 = winText5.get_rect()
                winRect.center = (centreX, 100)
                winRect2.center = (centreX, 200)
                winRect3.center = (centreX, 250)
                winRect4.center = (centreX, 300)
                winRect5.center = (centreX, 400)
                screen.blit(winText,winRect)
                screen.blit(winText2,winRect2)
                screen.blit(winText3,winRect3)
                screen.blit(winText4,winRect4)
                screen.blit(winText5,winRect5)

                pygame.display.update()

        #End Screen events (same for lose or win)
                for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                                        pygame.quit()
                                        sys.exit()
                        if event.type == pygame.KEYDOWN:
                                  #Quit Game
                                if event.key == pygame.K_q:
                                        pygame.quit()
                                        sys.exit()

#Lose end scenario
        while lose:
                screen.fill(Black)

                #Text block for final end screen
                loseText = bigtitleFont.render("OH NO!",False, White)
                loseText2 = insFont.render("You lost... thanks to your terrible defeat,", False, White)
                loseText3 = insFont.render("The Bloons achieved WORLD DOMINATION", False, White)
                loseText4 = insFont.render("and stole all the bananas!!", False, White)
                loseText5=instructionFont.render("To quit: press 'q'", False, White)
                loseRect = loseText.get_rect()
                loseRect2 = loseText2.get_rect()
                loseRect3 = loseText3.get_rect()
                loseRect4 = loseText4.get_rect()
                loseRect5 = loseText5.get_rect()
                loseRect.center = (centreX, 100)
                loseRect2.center = (centreX, 200)
                loseRect3.center = (centreX, 250)
                loseRect4.center = (centreX, 300)
                loseRect5.center = (centreX, 400)
                screen.blit(loseText,loseRect)
                screen.blit(loseText2,loseRect2)
                screen.blit(loseText3,loseRect3)
                screen.blit(loseText4,loseRect4)
                screen.blit(loseText5,loseRect5)

                pygame.display.update()

        #End Screen events (same for lose or win)
                for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                                        pygame.quit()
                                        sys.exit()
                        if event.type == pygame.KEYDOWN:
                                  #Quit Game
                                if event.key == pygame.K_q:
                                        pygame.quit()
                                        sys.exit()
                                        
                pygame.display.update()
                clock.tick(60)
